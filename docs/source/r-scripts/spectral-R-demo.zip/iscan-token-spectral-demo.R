# Author:  Patrick Reidy
# Purpose: Demo multitaper spectral analysis for Jane Stuart-Smith.
# Date:    2018-05-23

# Modified by:  Michael Goodale
# Purpose: ISCAN Token import/export tutorial
# Date:    2019-05-23

#NOTE: Depending on the corpus you use, you may have to modify the script.
# This is just the file structure of the corpus itself
# if the corpus has speaker directories, you don't need to do anything
# If the corpus doesn't have speaker directories, you just need to change one line below (details below)
sound_file_directory <- "/projects/spade/repo/git/spade-Buckeye/audio_and_transcripts"
parallelized <- TRUE
n_cores <- 20
corpus_data <- read.csv("buckeye.csv")

library(ggplot2)
library(magrittr)
library(multitaper)
library(tibble)
library(tuneR)
library(doParallel)
library(foreach)

# The R files in the ./auxiliary subdirectory of this demo define a handful of
# S4 classes, generics, and methods that wrap functionality from the tuneR and
# multitaper packages.
# You'll need to source the R files in this order because, e.g., definitions
# in later files depend on S4 classes defined in earlier files.
source('./auxiliary/Waveform.R') # For reading .wav files.
source('./auxiliary/Spectrum.R') # Base methods shared by all spectrum-like objects.
source('./auxiliary/Periodogram.R') # For estimating spectra using the periodogram.
source('./auxiliary/DPSS.R') # Windowing functions for multitaper spectra.
source('./auxiliary/Multitaper.R') # For estimating spectra using multitaper method.

# I apologize in advance if the comments below come off as pedantic. I don't 
# know your level of proficiency with R and its S4 class system, so I've 
# perhaps erred on the side of too much detail.

if(parallelized) {
    registerDoParallel(n_cores)
}else{
    n_cores = 1
}


#Split 0:nrows into (roughly) equal sized batches that are in order
batch_indices <- rep(0:(n_cores-1), each=(nrow(corpus_data) %/% n_cores))
batch_indices <- c(rep(0, nrow(corpus_data)-length(batch_indices)), batch_indices)

batches <- split(1:nrow(corpus_data), batch_indices)

corpus_data <- foreach(batch=batches, .combine=rbind) %dopar% {
    corpus_data <- corpus_data[batch, ]
    print(corpus_data)
    for (row in 1:nrow(corpus_data)){
        #To use for non-speaker directory corpora, just remove the speaker name and "/" from the paste function here.
        sound_file <- paste(corpus_data[row, "speaker_name"], "/", corpus_data[row, "sound_file_name"], '.wav', sep="")
        begin <- corpus_data[row, "phone_begin"]
        end <- corpus_data[row, "phone_end"]
        file_midpoint <- begin + (end-begin) / 2
        # Read the contents of the wav file.
	file_path <- file.path(sound_file_directory, sound_file)
	if(!file.exists(file_path)){
		next
	}
        sock <- Waveform(waveform = file_path, from = file_midpoint - 0.020, to = file_midpoint + 0.020)
        
        # The [sock] object is basically just a list of different pieces of information 
        # about audio waveform data stored in "slots".
        # The source code Waveform.R defines all of these slots.
        slotNames(sock)
        
        # Each of the slots has an associated accessor function:
        bitRate(sock) # an atomic integer
        sampleRate(sock) # an atomic integer
        N(sock) # an atomic integer
        startTime(sock) # an atomic double
        samples(sock)[1:10] # an integer vector (only showing the first 10 samples)
        
        # Estimate the spectrum of sock using the multitaper method.
        # PreEmphasize and ZeroPad are functions defined in ./auxiliary/Waveform.R
        # These functions are "data-first", so the operations can be daisy-chained 
        # together with the forward-pipe operator (%>%) from the magrittr package.
        # PreEmphasize applies a first-order FIR filter characterizd by:
        #   y[n] = x[n] - alpha*x[n-1].
        # ZeroPad just pastes zeroes onto the end of a waveform.
        # Multitaper requires two parameters: k, the number of tapers; nw, the time-bandwidth
        #   parameter. k=8 and nw=4 seem to be commonly used values.
        sock_spectrum <-
          sock %>%
          #PreEmphasize(alpha = 0.5) %>% # optional
          #ZeroPad(lengthOut = sampleRate(sock)) %>% # again, optional
          Multitaper(k = 8, nw = 4)
        
        # The show-method for a Multitaper object will generate a quick plot.
        sock_spectrum
        
        # Like a Waveform object, a Multitaper object is essentially a list of slots:
        slotNames(sock_spectrum)
        
        # The slots have associated accessor functions. tapers, k, and nw access slots
        # that track the parameter values and data tapers used to compute the MTS.
        values(sock_spectrum) # a numeric vector, the values ofthe MTS on the linear (i.e., not decibel) scale.
        binWidth(sock_spectrum) # an atomic numeric
        nyquist(sock_spectrum) # an atomic numeric
        
        # binWidth and nyquist are used to reconstruct the vector of frequencies at which
        # the MTS is defined:
        frequencies(sock_spectrum)
        
        # I suspect that you want to compute some feature or set of features from the MTS.
        # There are a few pre-defined functions for commonly computed features, e.g.
        # spectral moments:
        corpus_data[row, "spectral_centroid_linear"] <- centroid(sock_spectrum) # linear amplitude scale, all available frequencies
        corpus_data[row, "spectral_centroid_decibel"] <- centroid(sock_spectrum, scale = "decibel") # decibel scale, still all available frequencies
        centroid(sock_spectrum, minHz = 500) # linear scale, all frequencies above 500 hz
        centroid(sock_spectrum, scale = "decibel", minHz = 500, maxHz = 9000) # you get the idea
        # variance, skewness, and kurtosis also come pre-defined. These functions also 
        # have optional arguments scale, minHz, and maxHz, although I don't demo that
        # functionality here.
        corpus_data[row, "spectral_variance"] <- variance(sock_spectrum)
        corpus_data[row, "spectral_skewness"] <- skewness(sock_spectrum)
        corpus_data[row, "spectral_kurtosis"] <- kurtosis(sock_spectrum)
        
        # If you want to write functions for your own homebrewed features, the easiest
        # approach will probably be to write the function so that the values() and
        # frequencies() of a Multitaper object are passed as arguments, or so that these
        # are extracted from a Multitaper object within the function body.
        # E.g., here's a homebrewed function that computes the slope within a given 
        # frequency interval of a normalized spectrum (frequency scale z-scored;
        # amplitude scale log-transformed and then z-scored).
        spectralSlope <- function(mts, minHz = -Inf, maxHz = Inf) {
          .indices <- (function(.f) {which(minHz < .f & .f < maxHz)})(frequencies(mts))
          .freqs <- frequencies(mts)[.indices] %>% (function(.x) {(.x - mean(.x)) / sd(.x)})
          .values <- ((function(.v) {10 * log10(.v)})(values(mts)))[.indices] %>%
            (function(.x) {(.x - mean(.x)) / sd(.x)})
          .spec <- data.frame(x = .freqs, y = .values)
          .coeffs <- coef(lm(data = .spec, formula = y ~ x))
          return(coef(lm(data = .spec, formula = y ~ x))[2])
        }
        
        corpus_data[row, "spectral_slope"] <-  spectralSlope(sock_spectrum)
        spectralSlope(sock_spectrum, minHz = 500, maxHz = 9000)
    }
    corpus_data
}

stopImplicitCluster()

write.csv(corpus_data, "spectral_sibilants.csv")
